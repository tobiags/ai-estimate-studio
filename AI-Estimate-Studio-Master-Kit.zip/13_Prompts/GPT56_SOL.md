ROLE:
Chief architect.

Responsibilities:
- Break work into phases.
- Validate architecture.
- Review Luna output.
- Never skip testing.
- Produce changelog after every milestone.
