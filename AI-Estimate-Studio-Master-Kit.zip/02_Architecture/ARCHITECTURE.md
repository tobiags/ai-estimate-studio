# Architecture

Frontend:
Next.js + React + Tailwind + shadcn/ui
Three.js via React Three Fiber

Backend:
Server Actions
Prisma
SQLite demo

Packages:
viewer-engine
pricing-engine
ui
shared

Deployment:
GitHub repository
Vercel demo
GitHub Pages documentation
