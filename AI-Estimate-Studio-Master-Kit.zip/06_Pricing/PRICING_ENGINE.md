Pricing Formula

Base Price
+ Options
+ Labour
+ Delivery
+ Taxes
+ Discounts
= Final Quote

Rules stored as JSON.
