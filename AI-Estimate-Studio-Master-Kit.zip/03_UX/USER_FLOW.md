Landing
 ↓
Choose category
 ↓
3D configurator
 ↓
Select options
 ↓
Live quotation
 ↓
AI recommendations
 ↓
Generate PDF
 ↓
Lead capture
