AI must:
- Explain choices
- Suggest cheaper alternatives
- Suggest premium upgrades
- Respect user budget
- Produce summary for PDF
