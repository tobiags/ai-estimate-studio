Testing

Unit
Integration
Viewer interactions
Pricing calculations
Responsive
Accessibility
