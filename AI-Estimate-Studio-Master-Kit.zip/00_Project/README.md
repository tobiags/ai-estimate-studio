# AI Estimate Studio Master Kit

Goal: Build a premium portfolio-grade configurable quotation platform.

IMPORTANT:
Use https://github.com/thebuggeddev/anatomy ONLY as a technical viewer reference.
Generalize its viewer into ObjectViewer.
Remove every anatomy-specific concept.

Domains:
- Pools
- Pergolas
- Garden sheds
- Roofing

Deliver production-quality code.
