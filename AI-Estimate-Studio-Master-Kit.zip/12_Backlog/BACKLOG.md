Epic 1 Foundation
Epic 2 Viewer
Epic 3 Configurator
Epic 4 Pricing
Epic 5 AI
Epic 6 PDF
Epic 7 Admin
Epic 8 Polish

Each epic should be decomposed into implementation tasks by Codex.
