Entities

Category
Product
Variant
Option
Hotspot
PricingRule
Quote
Customer
