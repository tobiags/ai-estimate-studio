Video

1. Landing
2. Choose Pool
3. Configure
4. AI recommends
5. Price updates
6. Generate PDF
7. Contact CTA
