Development:
npm install
npm run dev

Production:
Deploy to Vercel.
Use GitHub Pages only for documentation.
