# Product Requirements

## Vision
Create a reusable quotation engine for home-improvement businesses.

## Personas
- Homeowners
- Sales reps
- Installers
- Company owner

## MVP
Landing → Configurator → Live price → AI advice → PDF → Contact

## Success
- Smooth 3D UX
- <2s initial load (excluding models)
- Mobile responsive
