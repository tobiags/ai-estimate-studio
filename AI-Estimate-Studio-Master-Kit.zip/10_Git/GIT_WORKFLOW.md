main
develop
feature/*
fix/*

Commit convention:
feat:
fix:
docs:
refactor:
