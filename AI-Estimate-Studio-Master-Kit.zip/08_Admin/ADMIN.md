Admin can:
Upload GLB
Create hotspots
Manage pricing
Manage categories
Publish products
