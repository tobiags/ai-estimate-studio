Endpoints

GET /products
GET /categories
POST /quote
POST /pdf
POST /assistant
